import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.*;

public class Buy_Frame extends JFrame{
	private String ID;
	private JPanel pan=new JPanel();
	private JLabel bus_lbl=new JLabel("���� ��ȣ");
	private JTextField bus_tf=new JTextField(20);
	private JLabel kind_lbl=new JLabel("���� ����");
	private JTextField kind_tf=new JTextField(20);
	private JLabel year_lbl=new JLabel("���� ����");
	private JTextField year_tf=new JTextField(20);
	private JLabel company_lbl=new JLabel("ȸ�� �̸�");
	private JTextField company_tf=new JTextField(20);
	private JButton buy_btn=new JButton("����");
	private JButton back_btn=new JButton("�ڷΰ���");
	
	private Socket socket;
	private ObjectInputStream reader=null;
	private ObjectOutputStream writer=null;
	
	public Buy_Frame(String str){
		ID=str;
		setTitle("Bus Buy");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(350,200);
		
		//���� ��ư ActionListener
		buy_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				try{
					InfoDTO dto = new InfoDTO();
					dto.setCommand(Info.ADDBUS);//Info.ADDBUS ���� ���� ����
					writer.writeObject(dto);
					writer.flush();
					writer.writeObject(bus_tf.getText());
					writer.flush();
					writer.writeObject(kind_tf.getText());
					writer.flush();
					writer.writeObject(year_tf.getText());
					writer.flush();
					writer.writeObject(company_tf.getText());
					writer.flush();
				}catch(IOException ioe){
					ioe.printStackTrace();
				}
			}
		});
		back_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				new Bus_Frame(ID);
				setVisible(false);
			}
		});
		
		pan.add(bus_lbl);
		pan.add(bus_tf);
		pan.add(kind_lbl);
		pan.add(kind_tf);
		pan.add(year_lbl);
		pan.add(year_tf);
		pan.add(company_lbl);
		pan.add(company_tf);
		pan.add(buy_btn);
		pan.add(back_btn);
		add(pan);
		setVisible(true);
	}

}
