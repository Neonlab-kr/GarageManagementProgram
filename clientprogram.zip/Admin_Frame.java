import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Admin_Frame extends JFrame {
	private JLabel ID_lbl=new JLabel("���� ��� ����");
	private JButton commit_btn=new JButton("���̵� ����");
	private JButton logout_btn=new JButton("�α׾ƿ�");
	private JComboBox ID_box=new JComboBox();
	public Admin_Frame(){
		setTitle("admin");
		setLayout(new FlowLayout());
		setSize(500,100);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		ID_box.setPreferredSize(new Dimension(150,20));
		logout_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				new Main_Frame();
				setVisible(false);
			}
		});
		add(ID_lbl);
		add(ID_box);
		add(commit_btn);
		add(logout_btn);
		setVisible(true);
	}
}