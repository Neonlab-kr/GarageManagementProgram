import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLException;

import javax.swing.*;

public class Join_Frame extends JFrame {
	private JPanel ID_panel=new JPanel();
	private JPanel job_panel=new JPanel();
	private JPanel password_panel=new JPanel();
	private JPanel name_panel=new JPanel();
	private JPanel address_panel=new JPanel();
	private JPanel age_panel=new JPanel();
	private JPanel tel_panel=new JPanel();
	private JPanel btn_panel=new JPanel();
	private JLabel ID_lbl=new JLabel("ID");
	private JLabel job_lbl=new JLabel("��å");
	private JLabel password_lbl=new JLabel("��й�ȣ");
	private JLabel name_lbl=new JLabel("�̸�");
	private JLabel address_lbl=new JLabel("�ּ�");
	private JLabel age_lbl=new JLabel("����");
	private JLabel tel_lbl=new JLabel("����ó");
	private JTextField ID_tf=new JTextField(18);
	private JTextField job_tf=new JTextField(20);
	private JTextField password_tf=new JTextField(20);
	private JTextField name_tf=new JTextField(20);
	private JTextField address_tf=new JTextField(20);
	private JTextField age_tf=new JTextField(20);
	private JTextField tel_tf=new JTextField(20);
	private JButton confirm_btn=new JButton("Ȯ��");
	private JButton join_btn=new JButton("���� ��û");
	private JButton cancel_btn=new JButton("���");
	
	private Socket socket;
	private ObjectInputStream reader=null;
	private ObjectOutputStream writer=null;
	
	private boolean isConfirm=false;
	
	public Join_Frame(){
		setTitle("Member Join");
		setSize(450,300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new GridLayout(8,1));
		
		ID_panel.add(ID_lbl);
		ID_panel.add(ID_tf);
		ID_panel.add(confirm_btn);
		add(ID_panel);
		
		job_panel.add(job_lbl);
		job_panel.add(job_tf);
		add(job_panel);
		
		password_panel.add(password_lbl);
		password_panel.add(password_tf);
		add(password_panel);
		
		name_panel.add(name_lbl);
		name_panel.add(name_tf);
		add(name_panel);
		
		address_panel.add(address_lbl);
		address_panel.add(address_tf);
		add(address_panel);
		
		age_panel.add(age_lbl);
		age_panel.add(age_tf);
		add(age_panel);
		
		tel_panel.add(tel_lbl);
		tel_panel.add(tel_tf);
		add(tel_panel);
		
		//Ȯ�� ��ư ActionListener
		confirm_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try {
					InfoDTO dto = new InfoDTO();
					dto.setCommand(Info.CONFIRM);//Info.CONFIRM ���̵� �ߺ� Ȯ�� ����
					writer.writeObject(dto);
					writer.flush();
					
					while(dto.getRs().next()) {
						if(dto.getRs().getString("���̵�").equals(ID_tf.getText())) {
							JOptionPane.showMessageDialog(null, "���̵� �ߺ�", "Error", JOptionPane.ERROR_MESSAGE);
							break;
						}
					}
					if(!dto.getRs().next()) {
						isConfirm=true;
					}
				}catch(IOException ioe){
					ioe.printStackTrace();
				}catch(SQLException se) {
					se.printStackTrace();
				}
			}
		});
		//���� ��û ��ư ActionListener
		join_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try {
					InfoDTO dto = new InfoDTO();
					dto.setCommand(Info.JOIN);//Info.JOIN ȸ�� ���� ��û ����
					writer.writeObject(dto);
					writer.flush();
					writer.writeObject(ID_tf.getText());
					writer.flush();
					writer.writeObject(job_tf.getText());
					writer.flush();
					writer.writeObject(password_tf.getText());
					writer.flush();
					writer.writeObject(name_tf.getText());
					writer.flush();
					writer.writeObject(address_tf.getText());
					writer.flush();
					writer.writeObject(age_tf.getText());
					writer.flush();
					writer.writeObject(tel_tf.getText());
					writer.flush();
				}catch(IOException ioe){
					ioe.printStackTrace();
				}
			}
		});
		//��� ��ư ActionListener
		cancel_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				new Main_Frame();
				setVisible(false);
			}
		});
		btn_panel.add(join_btn);
		btn_panel.add(cancel_btn);
		add(btn_panel);
		
		setVisible(true);		
	}
}
