import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLException;

import javax.swing.*;

public class profile_Frame extends JFrame{
	private String ID;
	private JLabel ID_lbl=new JLabel("���̵� : ");
	private JLabel job_lbl=new JLabel("��å : ");
	private JLabel password_lbl=new JLabel("��й�ȣ : ");
	private JLabel name_lbl=new JLabel("�̸� : ");
	private JLabel address_lbl=new JLabel("�ּ� : ");
	private JLabel age_lbl=new JLabel("���� : ");
	private JLabel tel_lbl=new JLabel("��ȭ��ȣ : ");
	private JLabel admit_lbl=new JLabel("���ο��� : ");
	private JPanel btn_panel=new JPanel();
	private JButton back_btn=new JButton("�ڷΰ���");
	
	private Socket socket;
	private ObjectInputStream reader=null;
	private ObjectOutputStream writer=null;
	
	public profile_Frame(String str){
		ID=str;
		setTitle(ID+"'s Profile");
		setLayout(new GridLayout(10,1));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(500,380);
		
		try {
			InfoDTO dto = new InfoDTO();
			dto.setCommand(Info.PROFILE);//Info.PROFILE ���̵� ������ ��� ����
			writer.writeObject(dto);
			writer.flush();
			writer.writeObject(ID);
			writer.flush();
			ID_lbl.setText(ID_lbl.getText()+dto.getRs().getString("���̵�"));
			job_lbl.setText(job_lbl.getText()+dto.getRs().getString("����"));
			password_lbl.setText(password_lbl.getText()+dto.getRs().getString("��й�ȣ"));
			name_lbl.setText(name_lbl.getText()+dto.getRs().getString("�̸�"));
			address_lbl.setText(address_lbl.getText()+dto.getRs().getString("�ֽ�"));
			age_lbl.setText(age_lbl.getText()+dto.getRs().getString("����"));
			tel_lbl.setText(tel_lbl.getText()+dto.getRs().getString("��ȭ��ȣ"));
			admit_lbl.setText(admit_lbl.getText()+dto.getRs().getString("���� ��û ����"));
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(SQLException se) {
			se.printStackTrace();
		}
		
		//�ڷΰ��� ��ư ActionListener
		back_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				new Bus_Frame(ID);
				setVisible(false);
			}
		});
		btn_panel.add(back_btn);
		
		add(ID_lbl);
		add(job_lbl);
		add(password_lbl);
		add(name_lbl);
		add(address_lbl);
		add(age_lbl);
		add(tel_lbl);
		add(admit_lbl);
		add(btn_panel);
		
		setVisible(true);
	}
}
