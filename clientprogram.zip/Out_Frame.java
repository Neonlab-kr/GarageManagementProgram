import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLException;
import java.util.Date;

import javax.swing.*;

public class Out_Frame extends JFrame{
	private String ID;
	private String[] hourValue={"0","1","2","3","4","5","6","7","8","9","10","11",
								"12","13","14","15","16","17","18","19","20","21","22","23"};
	private String[] minuteValue={"0","5","10","15","20","25","30","35","40","45","50","55"};
	private JPanel pan=new JPanel(new GridLayout(3,1));
	private JPanel subpan1=new JPanel();
	private JLabel bus_lbl=new JLabel("���� ��ȣ");
	private JComboBox bus_box=new JComboBox();
	private JPanel subpan2=new JPanel();
	private JLabel pre_in_lbl=new JLabel("���� ���� �ð�");
	private JComboBox pre_in_hour_box=new JComboBox(hourValue);
	private JComboBox pre_in_minute_box=new JComboBox(minuteValue);
	private JPanel subpan3=new JPanel();
	private JButton out_btn=new JButton("����");
	private JButton back_btn=new JButton("�ڷΰ���");
	
	private Socket socket;
	private ObjectInputStream reader=null;
	private ObjectOutputStream writer=null;
	
	public Out_Frame(String str){
		ID=str;
		setTitle("Bus Out");
		setSize(350,300);
		
		try{
			InfoDTO dto = new InfoDTO();
			dto.setCommand(Info.RECORD);
			writer.writeObject(dto);
			writer.flush();
			
			while(dto.getRs().next()){
				bus_box.addItem(dto.getRs().getString("������ȣ"));
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(SQLException se){
			se.printStackTrace();
		}
		bus_box.setPreferredSize(new Dimension(150,20));
		
		//���� ��ư ActionListener
		out_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				try{
					InfoDTO dto = new InfoDTO();
					dto.setCommand(Info.RECORD);
					writer.writeObject(dto);
					writer.flush();
					writer.writeObject(bus_box.getSelectedItem());
					writer.flush();
					writer.writeObject(pre_in_hour_box.getSelectedItem()+":"+pre_in_minute_box.getSelectedItem());
					writer.flush();
					writer.writeObject(new Date().getHours()+":"+new Date().getMinutes());
					writer.flush();
				}catch(IOException ioe){
					ioe.printStackTrace();
				}
			}
		});
		//�ڷΰ��� ��ư ActionListener
		back_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				new Bus_Frame(ID);
				setVisible(false);
			}
		});
		subpan1.add(bus_lbl);
		subpan1.add(bus_box);
		subpan2.add(pre_in_lbl);
		subpan2.add(pre_in_hour_box);
		subpan2.add(new JLabel("��"));
		subpan2.add(pre_in_minute_box);
		subpan2.add(new JLabel("��"));
		subpan3.add(out_btn);
		subpan3.add(back_btn);
		pan.add(subpan1);
		pan.add(subpan2);
		pan.add(subpan3);
		add(pan);
		setVisible(true);
	}
}
