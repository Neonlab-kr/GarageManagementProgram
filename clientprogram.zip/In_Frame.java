import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLException;
import java.util.Date;

import javax.swing.*;

public class In_Frame extends JFrame{
	private String ID;
	private JPanel pan=new JPanel(new GridLayout(3,1));
	private JPanel subpan1=new JPanel();
	private JLabel bus_lbl=new JLabel("���� ��ȣ");
	private JComboBox bus_box=new JComboBox();
	private JButton search_btn=new JButton("��ȸ");
	private JLabel pre_in_lbl=new JLabel("���� ���� �ð� : ");
	private JPanel subpan2=new JPanel();
	private JButton in_btn=new JButton("����");
	private JButton back_btn=new JButton("�ڷΰ���");
	
	private Socket socket;
	private ObjectInputStream reader=null;
	private ObjectOutputStream writer=null;
	
	private boolean isSearch=false;
	
	public In_Frame(String str){
		ID=str;
		setTitle("Bus In");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(350,300);
		
		try{
			InfoDTO dto = new InfoDTO();
			dto.setCommand(Info.BUSINFO);
			writer.writeObject(dto);
			writer.flush();
			
			while(dto.getRs().next()){
				bus_box.addItem(dto.getRs().getString("������ȣ"));
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(SQLException se) {
			se.printStackTrace();
		}
		
		bus_box.setPreferredSize(new Dimension(150,20));
		
		//��ȸ ��ư ActionListener
		search_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try{
					InfoDTO dto = new InfoDTO();
					dto.setCommand(Info.RECORD);//Info.RECORD ��� ��ȸ ����
					writer.writeObject(dto);
					writer.flush();
					if(dto.getRs().getString("���������ð�")==null)
					{
						JOptionPane.showMessageDialog(null, "���� �������� �����Դϴ�.","���",JOptionPane.ERROR_MESSAGE);
						isSearch=false;
					}
					else
					{
						pre_in_lbl.setText(pre_in_lbl.getText()+dto.getRs().getString("���������ð�"));
						isSearch=true;
					}
				}catch(IOException ioe){
					ioe.printStackTrace();
				}catch(SQLException se) {
					se.printStackTrace();
				}
			}
		});
		//���� ��ư ActionListener
		in_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				try{
					InfoDTO dto1 = new InfoDTO();
					dto1.setCommand(Info.RECORD);
					writer.writeObject(dto1);
					writer.flush();
					if(dto1.getRs().getString("���������ð�")==null)
					{
						JOptionPane.showMessageDialog(null, "���� �������� �����Դϴ�.","���",JOptionPane.ERROR_MESSAGE);
						isSearch=false;
					}
					else
					{
						InfoDTO dto2 = new InfoDTO();
						dto2.setCommand(Info.RECORD);
						writer.writeObject(dto2);
						writer.flush();
						writer.writeObject(bus_box.getSelectedItem().toString());
						writer.flush();
						writer.writeObject(dto1.getRs().getString("���������ð�"));
						writer.flush();
						writer.writeObject(new Date().getHours()+":"+new Date().getMinutes());
						writer.flush();
						isSearch=false;
					}
				}catch(IOException ioe){
					ioe.printStackTrace();
				}catch(SQLException se) {
					se.printStackTrace();
				}
			}
		});
		//�ڷΰ��� ��ư ActionListener
		back_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				new Bus_Frame(ID);
				setVisible(false);
			}
		});
		subpan1.add(bus_lbl);
		subpan1.add(bus_box);
		subpan1.add(search_btn);
		subpan2.add(in_btn);
		subpan2.add(back_btn);
		pan.add(subpan1);
		pan.add(pre_in_lbl);
		pan.add(subpan2);
		add(pan);
		setVisible(true);
	}
}
