public class Main{
	public static void main(String[] args) {
		Main_Frame fr=new Main_Frame();
	}
}