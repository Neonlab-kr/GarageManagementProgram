import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLException;

import javax.swing.*;
import javax.swing.table.*;

public class Cur_Frame extends JFrame{
	private String ID;
	private String colName[]={"���� ��ȣ","����","����","ȸ�� �̸�"};
	private DefaultTableModel model=new DefaultTableModel(colName,0);
	private JTable table=new JTable(model);
	private JPanel pan=new JPanel();
	private JComboBox combo=new JComboBox(colName);
	private JButton sort_btn=new JButton("����");
	private JButton back_btn=new JButton("�ڷΰ���");
	
	private Socket socket;
	private ObjectInputStream reader=null;
	private ObjectOutputStream writer=null;
	
	public Cur_Frame(String str){
		ID=str;
		setTitle("Bus Current Situation");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(550,600);
		
		try {
			InfoDTO dto = new InfoDTO();
			dto.setCommand(Info.BUSINFO);//Info.BUSINFO ���� ���� ��� ����
			writer.writeObject(dto);
			writer.flush();
			writer.writeObject(colName[0]);
			writer.flush();
			
			while(dto.getRs().next()) {
				String row[]=new String[4];
				row[0]=dto.getRs().getString("������ȣ");
				row[1]=dto.getRs().getString("����");
				row[2]=dto.getRs().getString("����");
				row[3]=dto.getRs().getString("ȸ��");
				
				model.addRow(row);
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(SQLException se) {
			se.printStackTrace();
		}
		
		JScrollPane scroll=new JScrollPane(table);
		//���� ��ư ActionListener
		sort_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try {
					DefaultTableModel m=(DefaultTableModel) table.getModel();
					m.setNumRows(0);
					InfoDTO dto = new InfoDTO();
					dto.setCommand(Info.BUSINFO);//Info.BUSINFO ���� ���� ��� ����
					writer.writeObject(dto);
					writer.flush();
					writer.writeObject(combo.getSelectedItem());
					writer.flush();
					
					while(dto.getRs().next()) {
						String row[]=new String[4];
						row[0]=dto.getRs().getString("������ȣ");
						row[1]=dto.getRs().getString("����");
						row[2]=dto.getRs().getString("����");
						row[3]=dto.getRs().getString("ȸ��");
						
						model.addRow(row);
					}
				}catch(IOException ioe){
					ioe.printStackTrace();
				}catch(SQLException se) {
					se.printStackTrace();
				}
			}
		});
		//�ڷΰ��� ��ư ActionListener
		back_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				new Bus_Frame(ID);
				setVisible(false);
			}
		});
		pan.add(combo);
		pan.add(sort_btn);
		pan.add(scroll);
		pan.add(back_btn);
		
		
		add(pan);
		setVisible(true);
	}
}
