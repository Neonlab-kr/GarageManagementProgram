import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import java.io.*;
import java.net.*;
import java.sql.SQLException;

public class Main_Frame extends JFrame implements ActionListener,Runnable{

	private JPanel title_panel=new JPanel();
	private JPanel login_panel=new JPanel();
	private JPanel p2=new JPanel();
	private JLabel Title=new JLabel("Garage Management Program");
	private JLabel ID_lbl=new JLabel("ID");
	private JLabel PW_lbl=new JLabel("Password");
	private JButton btn_login=new JButton("�α���");
	private JButton join_btn=new JButton("ȸ������");
	private JButton btn_quit=new JButton("����");
	private JTextField ID_tf=new JTextField(15);
	private JPasswordField PW_tf=new JPasswordField(15);
	
	private Socket socket;
	private ObjectInputStream reader=null;
	private ObjectOutputStream writer=null; 
	
	private Thread t;
	
	public Main_Frame(){
		service();
		setTitle("Garage Management Program");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new GridLayout(3,1));
		setResizable(false);
		setSize(450,300);
		
		//������ �̺�Ʈ
		this.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){ 
				try{
					InfoDTO dto = new InfoDTO();
					dto.setCommand(Info.EXIT);
					writer.writeObject(dto);
					writer.flush();
				}catch(IOException io){
					io.printStackTrace();
				}
			}
		});

		Title.setFont(new Font("Serif",Font.BOLD,30));
		title_panel.add(Title);
		add(title_panel);
		
		login_panel.add(ID_lbl);
		login_panel.add(ID_tf);
		login_panel.add(PW_lbl);
		login_panel.add(PW_tf);
		add(login_panel);

		//�α��� ��ư ActionListener
		btn_login.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				if(ID_tf.getText().equals("admin")&&PW_tf.getText().equals("1234"))
				{
					new Admin_Frame();
					setVisible(false);
				}
				else
				{
					try{		
						InfoDTO dto = new InfoDTO();
						dto.setCommand(Info.LOGIN);//Info.LOGIN �α��� ����
						writer.writeObject(dto);
						writer.flush();
						
						while(dto.getRs().next()) {
							if(dto.getRs().getString("���̵�").equals(ID_tf.getText())
									&&dto.getRs().getString("��й�ȣ").equals(PW_tf.getText())) {
								new Bus_Frame(ID_tf.getText());
								setVisible(false);
							}
						}
					}catch(IOException ioe){
						ioe.printStackTrace();
					}catch(SQLException se) {
						se.printStackTrace();
					}
				}
			}
		});
		//ȸ������ ��ư ActionListener
		join_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				new Join_Frame();
				setVisible(false);
			}
		});
		//���� ��ư ActionListener
		btn_quit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				try{		
					InfoDTO dto = new InfoDTO();
					dto.setCommand(Info.EXIT);//Info.EXIT ���� ����
					writer.writeObject(dto);
					writer.flush();
				}catch(IOException e){
					e.printStackTrace();
				}
			}
		});
		p2.add(btn_login);
		p2.add(join_btn);
		p2.add(btn_quit);
		add(p2);
		
		setVisible(true);
	}
	
	public void service(){
		try{
			socket = new Socket("111.222.33.4",9500);
			reader= new ObjectInputStream(socket.getInputStream());
			writer = new ObjectOutputStream(socket.getOutputStream());
			System.out.println("���� �Ϸ�!"); 
			
		} catch(UnknownHostException e ){
			System.out.println("������ ã�� �� �����ϴ�.");
			e.printStackTrace();
			System.exit(0);
		} catch(IOException e){
			System.out.println("������ ������ �ȵǾ����ϴ�.");
			e.printStackTrace();
			System.exit(0);
		}		
		t = new Thread(this);
		t.start();
	}
	@Override
	public void run(){
		InfoDTO dto= null;
		while(true){
			try{
				dto = (InfoDTO) reader.readObject();
				if(dto.getCommand()==Info.EXIT){  //�����κ��� �� �ڽ��� exit�� ������ �����
					reader.close();
					writer.close();
					socket.close();
					System.exit(0);
				}
			}catch(IOException e){
				e.printStackTrace();
			}catch(ClassNotFoundException e){
				e.printStackTrace();
			}	
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
