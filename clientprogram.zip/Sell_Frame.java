import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLException;

import javax.swing.*;

public class Sell_Frame extends JFrame {
	private String ID;
	private JPanel bus_panel=new JPanel();
	private JLabel bus_lbl=new JLabel("���� ��ȣ");
	private JComboBox bus_box=new JComboBox();
	private JButton search_btn=new JButton("��ȸ");
	private JLabel kind_lbl=new JLabel("���� ���� : ");
	private JLabel year_lbl=new JLabel("���� ���� : ");
	private JLabel company_lbl=new JLabel("ȸ�� �̸� : ");
	private JPanel btn_panel=new JPanel();
	private JButton sell_btn=new JButton("�ŵ�");
	private JButton back_btn=new JButton("�ڷΰ���");
	private JPanel search_panel=new JPanel();
	
	private Socket socket;
	private ObjectInputStream reader=null;
	private ObjectOutputStream writer=null;
	
	public Sell_Frame(String str){
		ID=str;
		setTitle("Bus Sell");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new GridLayout(3,1));
		setSize(400,300);
		
		try{
			InfoDTO dto = new InfoDTO();
			dto.setCommand(Info.BUSINFO);
			writer.writeObject(dto);
			writer.flush();
			
			while(dto.getRs().next()){
				bus_box.addItem(dto.getRs().getString("������ȣ"));
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(SQLException se){
			se.printStackTrace();
		}
		
		bus_box.setPreferredSize(new Dimension(105,20));
		
		search_panel.setLayout(new GridLayout(3,1));
		//��ȸ ��ư ActionListener
		search_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				try{
					InfoDTO dto = new InfoDTO();
					dto.setCommand(Info.BUSINFO);
					writer.writeObject(dto);
					writer.flush();
					if(dto.getRs().getString("������ȣ").equals(bus_box.getSelectedItem().toString()))
					{
						kind_lbl.setText(kind_lbl.getText()+dto.getRs().getString("����"));
						year_lbl.setText(year_lbl.getText()+dto.getRs().getString("����"));
						company_lbl.setText(company_lbl.getText()+dto.getRs().getString("ȸ��"));
					}
				}catch(IOException ioe){
					ioe.printStackTrace();
				}catch(SQLException se){
					se.printStackTrace();
				}
			}
		});
		//�ŵ� ��ư ActionListener
		sell_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				try{
					InfoDTO dto = new InfoDTO();
					dto.setCommand(Info.SUBBUS);//Info.SELLBUS ���� �ŵ� ����
					writer.writeObject(dto);
					writer.flush();
					writer.writeObject(bus_box.getSelectedItem().toString());
					writer.flush();
				}catch(IOException ioe){
					ioe.printStackTrace();
				}
			}
		});
		//�ڷΰ��� ��ư ActionListener
		back_btn.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				new Bus_Frame(ID);
				setVisible(false);
			}
		});
		
		bus_panel.add(bus_lbl);
		bus_panel.add(bus_box);
		bus_panel.add(search_btn);
		add(bus_panel);
		search_panel.add(kind_lbl);
		search_panel.add(year_lbl);
		search_panel.add(company_lbl);
		add(search_panel);
		btn_panel.add(sell_btn);
		btn_panel.add(back_btn);
		add(btn_panel);
		setVisible(true);
	}
}